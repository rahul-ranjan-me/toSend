# Rahul Ranjan (rahul.smile@gmail.com)
## I have tested it on chrome and safari mac
## Libraries used are
- moment.js
- jquery.js
- react
## Bootstraping is been done from create-react-app
## All src files are kept in the src folder
## Run command
- clone/or unzip to a folder
- run npm i 
- run npm start