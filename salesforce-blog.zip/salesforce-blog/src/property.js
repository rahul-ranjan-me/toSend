const property = {
    apiURL : 'http://restedblog.herokuapp.com/shubham/api/'
}

export default property